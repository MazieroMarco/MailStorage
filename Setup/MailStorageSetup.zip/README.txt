=============== INSTRUCTIONS D'INSTALLATION DU PROGRAMME MAILSTORAGE =============

1. Lancer le programme d'installation "MailStorageSetup"

2. Suivre les instructions d'installation

3. Lancer le programme


========================= AVERTISSEMENTS AVANT UTILISATION =======================

Si la connexion �choue constamment :

	Activer l'utilisation de clients mail moins s�curis�s dans les r�glages du client mail


Si le programme ne semble pas fonctionner correctement :

	Utiliser le serveur IMAP de Gmail, il semble �tre le plus stable




